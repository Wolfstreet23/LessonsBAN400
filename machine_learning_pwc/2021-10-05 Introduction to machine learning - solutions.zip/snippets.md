# How to add snippets in your code

1. Go to ```Tools``` --> ```Global Options``` --> ```Code``` --> ```Edit Snippets```
2. Scroll down to the bottom
3. Add the following code
```
snippet sec
	##################################### #
	# ${1:section} ----
	##################################### #
```
4. Press save
5. Start to type ```sec``` in a new script and hit either tab or enter to obtain a section block

