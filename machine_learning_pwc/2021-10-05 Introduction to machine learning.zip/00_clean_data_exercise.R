source("utils.R")

#################### #
# Exercise 1 - Import data from input folder ----
#################### #

# Insert the appropriate function to import all the data sets from the input folder to R
houses_raw        <- read_excel("input/houses.xlsx")
geo_raw           <- "to do"
zip_raw           <- "to do"
income_raw        <- "to do"
attributes_raw    <- "to do"


#################### #
# Exercise 2 - Select relevant variables ----
#################### #

# Run the next lines
geo <- geo_raw %>% 
  select(id, kommune_no, kommune_name, fylke_no, fylke_name)


# Select variables for zip number, average income and average fortune from the income data set
income <- income_raw %>% 
  select(zip_no      = postnr,
         avg_income  = "to do",
         avg_fortune = "to do")

# Run the next lines as no changes are needed for zip_raw and attributes_raw
zip        <- zip_raw
attributes <- attributes_raw

#################### #
# Exercise 3 - Merge data ----
#################### #

# Merge all data sets using the left join function to join on the appropriate variable 
houses <- houses_raw %>% 
  left_join(geo, by = "to do") %>%
  left_join("to do", by = "to do") %>% 
  left_join("to do", by = "to do") %>% 
  left_join("to do", by = "to do")
  
  
##################################### #
# Exercise  4 ---- Prep and plot 
##################################### #

# Replace na values with 0 for variables debt and expense 
# Calculate total price (price plus debt)
# Optional: Create a new feature of your own choice that you think could have an impact on the model

houses_output <- houses %>% 
  mutate(debt       = "to do",
         expense    = "to do",
         tot_price  = "to do", 
         tot_price_per_sqm = tot_price/sqm) %>% 
  drop_na()

# Run the next lines to study the distribution of the price variable
houses_output %>% 
  ggplot(aes(x = tot_price/1E6)) +
  geom_histogram(fill = "dodgerblue3", color = "white") +
  labs(x = "Pris [MNOK]",
       y = "Antall") +
  xlim(0, 10) +
  theme_minimal()

# Run the next lines to study the relation between price and sqm
houses_output %>% 
  ggplot(aes(x = sqm, y = tot_price/1E6)) +
  geom_point(color = "dodgerblue3", alpha = 0.4) +
  labs(x = "Kvadratmeter",
       y = "Pris [MNOK]") +
  theme_minimal() 

# Insert the appropriate function to perform log transformation of both price and sqm
# Study how the relation changes when the effect of outliers is reduced
houses_output %>% 
  ggplot(aes(x = "to do"(sqm), y = "to do"(tot_price/1E6))) +
  geom_point(color = "dodgerblue3", alpha = 0.4) +
  labs(x = "log(Kvadratmeter)",
       y = "log(Pris [MNOK])") +
  theme_minimal()


#################### #
# Excerise 5 - Write data to excel ----
#################### #

# Insert the appropriate function to save the data set
"to do"("to do", "temp/houses_exercise.xlsx")
