source("utils.R")

#################### #
# Exercise 1 - Import data ----
#################### #

# Insert the appropriate function to import the `houses.xlsx` dataset to R
houses_raw <- "to do"

#################### #
# Exercise 2 - Split data ----
#################### #

set.seed(42)

# Split 75 % of the data to the training set, and the rest to the test set
split <- initial_split(houses_raw, "to do")
train_raw <- "to do"
test_raw  <- "to do"

#################### #
# Exercise 3 - Create recipe and prepare  ----
#################### #

# Create a recipe that 
# (1) only keep the variables sqm, expense, total price, latitude, longitude, and municipality (kommune), 
# (2) log transforms  and 
# (3) lumps municipalities with less than 20 observations into an "other" category
# (4) one hot encode categorical variables

recipe <- train_raw %>% 
  recipe(tot_price ~ .) %>% 
  step_"to do" %>% 
  step_"to do" %>% 
  step_"to do" %>% 
  step_"to_do" %>% 
  prep()

# Create train and test data sets
train <- bake(recipe, "to do")
test  <- bake(recipe, "to do")

#################### #
# Exercise 4 - Fit a linear model  ----
#################### #

# Set the target variable as the logarithm of total price and fit the linear model
model <- linear_reg() %>% 
  set_engine("lm") %>% 
  fit("to do" ~ ., data = "to do")

# Run the next line to view summary of fit
summary(model$fit)

#################### #
# Exercise 5 - Use model for predictions  ----
#################### #

# Use the fitted model to predict the total price for observations in the test set
# Remember to take the exponential of the .pred to return meaningful prediction values
# Also find the appropriate function to rename columns
model_preds <- 
  predict("to do", new_data = "to do") %>%
  bind_cols(test) %>% 
  mutate(.pred = "to do"(.pred)) %>%     
  "to do"(estimate     = .pred,
         truth        = tot_price) %>% 
  mutate(abs_dev      = abs(truth - estimate),
         abs_dev_perc = abs_dev/truth)

#################### #
# Exercise 6 - Evaluate model  ----
#################### #

# Evaluate the mean absolute percentage error of our linear model predictions
mape(data     = "to do",
     truth    = "to do",
     estimate = "to do")

##################################### #
# Excerise 7 - Plot results ----
##################################### #

# Run the next lines to study the distribution of the percentage error
model_preds %>%
  ggplot(aes(x = abs_dev_perc)) +
  geom_histogram(fill = "dodgerblue3", color = "white") +
  theme_minimal() +
  labs(x = "Prosentvis feil",
       y = "Antall observasjoner") +
  scale_x_continuous(limits = c(0, 5), labels = scales::percent)

