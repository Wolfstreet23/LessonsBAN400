source("utils.R")

#################### #
# Exercise 1 - Copy the code from exercise 2 (linear model) and rewrite to 
# a xgboost model ----
#################### #

# to do

#################### #
# Exercise 2 - Try to improve the model by adding more variables ----
#################### #

# to do

#################### #
# Exercise 3 - Explore the results through visualization, e.g.:
# * Distribution of error in big/small municipalities ----
# * Distribution of error for buckets of square meters
# * Error vs price
#################### #